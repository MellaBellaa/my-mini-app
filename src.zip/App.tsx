import { FormEvent, useEffect, useRef, useState } from 'react'

type IconName = 'home' | 'folder' | 'sparkles' | 'plus' | 'arrow' | 'app' | 'site' | 'game' | 'bug' | 'bulb' | 'clock'
type Mode = 'app' | 'site' | 'game' | 'bug' | 'bulb'
type GeneratedResult = { mode: Mode; label: string; title: string; summary: string; items: string[]; action: string }
type WebsiteDetails = { color: string; businessName: string; owner: string; about: string; blurb: string; font: string; logo: string; founderPhoto: string }

const Icon = ({ name, className = 'h-5 w-5' }: { name: IconName; className?: string }) => {
  const paths: Record<IconName, React.ReactNode> = {
    home: <><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9M9 20v-7h6v7"/></>,
    folder: <><path d="M3 6.5A2.5 2.5 0 0 1 5.5 4H9l2 2h7.5A2.5 2.5 0 0 1 21 8.5v8A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5Z"/></>,
    sparkles: <><path d="m12 3 1.2 3.3L16.5 7.5l-3.3 1.2L12 12l-1.2-3.3-3.3-1.2 3.3-1.2Z"/><path d="m18.5 13 .8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8Z"/><path d="m5.5 14 .7 1.8 1.8.7-1.8.7L5.5 19l-.7-1.8-1.8-.7 1.8-.7Z"/></>,
    plus: <path d="M12 5v14M5 12h14"/>,
    arrow: <path d="M5 12h14m-5-5 5 5-5 5"/>,
    app: <><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><path d="M14 17.5h7M17.5 14v7"/></>,
    site: <><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M7 6.5h.01M10 6.5h.01"/></>,
    game: <><path d="M8 8h8a5 5 0 0 1 4.7 6.7l-1 2.9a2 2 0 0 1-3.3.8L14 16h-4l-2.4 2.4a2 2 0 0 1-3.3-.8l-1-2.9A5 5 0 0 1 8 8Z"/><path d="M8 11v4M6 13h4M16.5 12h.01M18.5 14h.01"/></>,
    bug: <><path d="M8 9h8v7a4 4 0 0 1-8 0Z"/><path d="M9 9a3 3 0 0 1 6 0M4 13h4M16 13h4M5 18l3-1M19 18l-3-1M12 5V3"/></>,
    bulb: <><path d="M9 18h6M10 21h4"/><path d="M8.2 14.2A6 6 0 1 1 15.8 14c-1 .8-1.3 1.5-1.3 2H9.5c0-.5-.3-1.2-1.3-2Z"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  }
  return <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>
}

const starters = [
  { icon: 'app' as const, mode: 'app' as const, title: 'Build an app', copy: 'Turn an idea into a useful app.', color: 'bg-[#e8e0ff] text-[#7756d8]', prompt: 'Build me a simple app that ' },
  { icon: 'site' as const, mode: 'site' as const, title: 'Create a website', copy: 'For school, business, or yourself.', color: 'bg-[#d8f0eb] text-[#308b79]', prompt: 'Create a website for ' },
  { icon: 'game' as const, mode: 'game' as const, title: 'Make a game', copy: 'Bring your game idea to life.', color: 'bg-[#fff0cf] text-[#ca8322]', prompt: 'Make a fun game where ' },
  { icon: 'bug' as const, mode: 'bug' as const, title: 'Fix a problem', copy: 'Find mistakes and repair your code.', color: 'bg-[#ffe0dc] text-[#d95f54]', prompt: 'Help me fix this problem: ' },
  { icon: 'bulb' as const, mode: 'bulb' as const, title: 'Improve an idea', copy: 'Get smart suggestions and new features.', color: 'bg-[#ddebff] text-[#4c78cf]', prompt: 'Help me improve my idea for ' },
]

const resultFor = (mode: Mode, idea: string, website: WebsiteDetails): GeneratedResult => {
  const topic = idea.replace(/^(build me|create|make|help me|a|an)\s+/i, '').replace(/[.:]\s*$/, '') || 'your idea'
  const results: Record<Mode, Omit<GeneratedResult, 'mode'>> = {
    app: { label: 'App plan generated', title: 'Your app is mapped out', summary: `A focused, beginner-friendly app based on “${topic}” with a clear first version ready to build.`, items: ['Simple onboarding and home dashboard', 'Core task flow with saved progress', 'Responsive design for phone and desktop'], action: 'Build app prototype' },
    site: { label: 'Website generated', title: `${website.businessName || 'Your business'} website blueprint`, summary: website.blurb || `A polished website for “${topic}” designed to explain the idea clearly and guide visitors to act.`, items: [`Brand style: ${website.font} with ${website.color}`, `Founder story featuring ${website.owner}`, `About section: ${website.about}`], action: 'Create website preview' },
    game: { label: 'Game concept generated', title: 'Your game loop is ready', summary: `A playable concept inspired by “${topic}” with simple rules that can grow over time.`, items: ['Easy controls and a clear objective', 'Score, levels, and increasing challenge', 'Start, pause, win, and replay screens'], action: 'Build first level' },
    bug: { label: 'Problem analyzed', title: 'A fix has been prepared', summary: `Buildly reviewed “${topic}” and created a safe troubleshooting path to isolate the likely cause.`, items: ['Reproduce and identify the failing step', 'Correct the broken state or input handling', 'Add a check to prevent the issue returning'], action: 'Apply suggested fix' },
    bulb: { label: 'Ideas generated', title: 'Your concept just got stronger', summary: `New ways to make “${topic}” more useful, engaging, and easier for people to understand.`, items: ['Add a guided first-time experience', 'Personalize results around user goals', 'Include sharing and progress milestones'], action: 'Add these improvements' },
  }
  return { mode, ...results[mode] }
}

const projects = [
  { title: 'Plant care tracker', type: 'App', updated: '2 hours ago', icon: 'app' as const, color: 'bg-[#e9e2ff] text-[#7859d7]' },
  { title: 'History class timeline', type: 'Website', updated: 'Yesterday', icon: 'site' as const, color: 'bg-[#dff3ee] text-[#348b7a]' },
  { title: 'Space runner', type: 'Game', updated: '3 days ago', icon: 'game' as const, color: 'bg-[#fff1d4] text-[#c98022]' },
  { title: 'Bakery landing page', type: 'Website', updated: '1 week ago', icon: 'site' as const, color: 'bg-[#ffe6df] text-[#c66152]' },
  { title: 'Study buddy', type: 'App', updated: '2 weeks ago', icon: 'app' as const, color: 'bg-[#e2edff] text-[#4f72bc]' },
]

const websiteLink = (name: string) => `${window.location.origin}${window.location.pathname}#/site/${(name || 'my-website').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`
const appName = (prompt: string) => {
  const cleaned = prompt.replace(/^(build me|create|make)\s+(a|an)?\s*(simple\s+)?app\s+(that|for|to)?\s*/i, '').trim()
  if (!cleaned) return 'My App'
  return cleaned.split(/\s+/).slice(0, 5).join(' ').replace(/^./, (letter) => letter.toUpperCase())
}
const appLink = (prompt: string) => `${window.location.origin}${window.location.pathname}#/app/${appName(prompt).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`
const gameName = (prompt: string) => appName(prompt.replace(/\bapp\b/i, 'game'))
const gameLink = (prompt: string) => `${window.location.origin}${window.location.pathname}#/game/${gameName(prompt).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`
const safe = (value: string) => value.replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]!)
const downloadCode = (filename: string, code: string) => {
  const url = URL.createObjectURL(new Blob([code], { type: 'text/html;charset=utf-8' }))
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  link.click()
  URL.revokeObjectURL(url)
}
const appCode = (prompt: string) => `<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${safe(appName(prompt))}</title><style>
*{box-sizing:border-box}body{margin:0;background:#f4f2f8;color:#242329;font:15px Arial,sans-serif}.wrap{max-width:720px;margin:0 auto;padding:48px 20px}
.hero{padding:34px;border-radius:28px;color:white;background:linear-gradient(135deg,#775bd4,#5036a7);box-shadow:0 20px 50px #5136a938}
.card{margin-top:22px;padding:26px;border:1px solid #e3dfea;border-radius:24px;background:white}h1{margin:8px 0;font-size:36px}p{line-height:1.6}
form,.item{display:flex;gap:10px}input{flex:1;padding:13px;border:1px solid #ddd8e5;border-radius:12px}button{border:0;border-radius:12px;padding:0 18px;background:#7257d5;color:white;font-weight:bold;cursor:pointer}
.item{align-items:center;margin-top:9px;padding:14px;border:1px solid #ece9ef;border-radius:12px}.item span{flex:1}.done{text-decoration:line-through;color:#999}.toggle,.delete{width:28px;height:28px;padding:0}.delete{background:#eee;color:#777}
</style></head><body><main class="wrap"><section class="hero"><small>YOUR WORKSPACE</small><h1>${safe(appName(prompt))}</h1><p>${safe(prompt)}</p></section>
<section class="card"><h2>Your items</h2><form id="form"><input id="input" placeholder="Add something new..." required><button>Add</button></form><div id="list"></div></section></main>
<script>let items=[{text:"Explore your new app",done:true},{text:"Add your first item",done:false}];
const list=document.querySelector("#list");function render(){list.innerHTML="";items.forEach((item,i)=>{const row=document.createElement("div");row.className="item";row.innerHTML='<button class="toggle">'+(item.done?"✓":"")+'</button><span class="'+(item.done?"done":"")+'"></span><button class="delete">×</button>';row.querySelector("span").textContent=item.text;row.querySelector(".toggle").onclick=()=>{items[i].done=!items[i].done;render()};row.querySelector(".delete").onclick=()=>{items.splice(i,1);render()};list.appendChild(row)})}document.querySelector("#form").onsubmit=e=>{e.preventDefault();const input=document.querySelector("#input");items.push({text:input.value,done:false});input.value="";render()};render();</script></body></html>`
const websiteCode = (website: WebsiteDetails) => `<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${safe(website.businessName)}</title>
<style>*{box-sizing:border-box}body{margin:0;color:#242329;font:16px Arial,sans-serif}header,section,footer{max-width:1100px;margin:auto;padding:24px 40px}header{display:flex;align-items:center;justify-content:space-between;font-weight:bold}.logo{width:48px;height:48px;object-fit:contain}
.hero{display:grid;grid-template-columns:1.1fr .9fr;align-items:center;gap:60px;padding-top:100px;padding-bottom:110px}h1{font-size:64px;line-height:1.05;margin:16px 0}p{color:#666;line-height:1.8}.art{height:380px;border-radius:36px;background:linear-gradient(145deg,${safe(website.color)},#25222c)}
.button{display:inline-block;margin-top:20px;padding:14px 24px;border-radius:99px;background:${safe(website.color)};color:white;text-decoration:none;font-weight:bold}.about{text-align:center;padding-top:90px;padding-bottom:90px}.founder{width:120px;height:120px;border-radius:50%;object-fit:cover}
footer{border-top:1px solid #eee}@media(max-width:700px){header,section,footer{padding-left:20px;padding-right:20px}.hero{grid-template-columns:1fr;padding-top:60px}.art{height:260px}h1{font-size:44px}}</style></head>
<body><header>${website.logo ? `<img class="logo" src="${safe(website.logo)}" alt="Logo">` : ''}<span>${safe(website.businessName)}</span></header>
<main><section class="hero"><div><small>WELCOME TO ${safe(website.businessName).toUpperCase()}</small><h1>Something meaningful, made for you.</h1><p>${safe(website.blurb)}</p><a class="button" href="#about">Discover our story</a></div><div class="art"></div></section>
<section class="about" id="about">${website.founderPhoto ? `<img class="founder" src="${safe(website.founderPhoto)}" alt="${safe(website.owner)}">` : ''}<h2>Meet ${safe(website.owner)}</h2><p>${safe(website.about)}</p></section></main>
<footer>© ${new Date().getFullYear()} ${safe(website.businessName)}</footer></body></html>`
const gameCode = (prompt: string) => `<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${safe(gameName(prompt))}</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#171522;color:white;font:16px Arial,sans-serif}
.game{width:min(760px,92vw);text-align:center}.top{display:flex;justify-content:space-between;align-items:end;margin-bottom:18px}h1{margin:5px 0;font-size:32px}.stats{display:flex;gap:10px}.stat{padding:10px 16px;border-radius:12px;background:#29263a;font-weight:bold}
.arena{position:relative;height:450px;overflow:hidden;border:1px solid #49445e;border-radius:28px;background:radial-gradient(circle at 50% 30%,#342d58,#1e1b2b)}
.target{position:absolute;width:64px;height:64px;border:0;border-radius:50%;background:linear-gradient(135deg,#ffd66b,#ff7b54);box-shadow:0 0 28px #ff9a50aa;cursor:pointer;transform:translate(-50%,-50%);font-size:24px}
.start{margin-top:18px;padding:14px 28px;border:0;border-radius:14px;background:#7659d4;color:white;font-weight:bold;cursor:pointer}</style></head>
<body><main class="game"><div class="top"><div><small>BUILT WITH BUILDLY</small><h1>${safe(gameName(prompt))}</h1></div><div class="stats"><span class="stat">Score: <b id="score">0</b></span><span class="stat">Time: <b id="time">20</b>s</span></div></div>
<div class="arena" id="arena"><button class="target" id="target" hidden>★</button></div><button class="start" id="start">Start game</button></main>
<script>let score=0,time=20,timer;const target=document.querySelector("#target");function move(){target.style.left=(8+Math.random()*84)+"%";target.style.top=(10+Math.random()*80)+"%"}
target.onclick=()=>{score++;document.querySelector("#score").textContent=score;move()};document.querySelector("#start").onclick=function(){score=0;time=20;this.textContent="Playing…";this.disabled=true;target.hidden=false;move();document.querySelector("#score").textContent=0;document.querySelector("#time").textContent=time;clearInterval(timer);timer=setInterval(()=>{time--;document.querySelector("#time").textContent=time;if(time<=0){clearInterval(timer);target.hidden=true;this.disabled=false;this.textContent="Play again — score "+score}},1000)}</script></body></html>`

const WebsitePreview = ({ website }: { website: WebsiteDetails }) => {
  const fontFamily = website.font.includes('Elegant') ? 'Georgia, serif' : website.font.includes('Editorial') ? '"Times New Roman", serif' : website.font.includes('Rounded') ? '"Trebuchet MS", sans-serif' : 'Arial, sans-serif'
  return (
    <div className="min-h-screen bg-white text-[#242329]" style={{ fontFamily }}>
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5 md:px-10">
        <div className="flex items-center gap-3">
          {website.logo ? <img src={website.logo} alt={`${website.businessName} logo`} className="h-11 w-11 rounded-xl object-contain" /> : <span className="h-10 w-10 rounded-xl" style={{ backgroundColor: website.color }} />}
          <span className="text-lg font-bold">{website.businessName}</span>
        </div>
        <a href="mailto:hello@example.com" className="rounded-full px-5 py-2.5 text-sm font-bold text-white" style={{ backgroundColor: website.color }}>Get in touch</a>
      </header>
      <main>
        <section className="mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 md:grid-cols-2 md:px-10 md:py-28">
          <div>
            <p className="mb-5 text-xs font-bold uppercase tracking-[0.16em]" style={{ color: website.color }}>Welcome to {website.businessName}</p>
            <h1 className="text-5xl font-bold leading-[1.05] tracking-[-0.05em] md:text-7xl">Something meaningful, made for you.</h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-[#65636a]">{website.blurb}</p>
            <a href="#about" className="mt-8 inline-block rounded-full px-6 py-3.5 text-sm font-bold text-white" style={{ backgroundColor: website.color }}>Discover our story</a>
          </div>
          <div className="aspect-[4/3] rounded-[36px] p-10" style={{ backgroundColor: `${website.color}18` }}>
            <div className="flex h-full items-end rounded-[28px] p-7 text-white shadow-xl" style={{ background: `linear-gradient(145deg, ${website.color}, #25222c)` }}>
              <p className="max-w-xs text-2xl font-bold leading-tight">{website.businessName}<br />Ideas brought to life.</p>
            </div>
          </div>
        </section>
        <section id="about" className="px-6 py-20 md:px-10" style={{ backgroundColor: `${website.color}0d` }}>
          <div className="mx-auto flex max-w-4xl flex-col items-center gap-8 text-center">
            {website.founderPhoto && <img src={website.founderPhoto} alt={website.owner} className="h-28 w-28 rounded-full object-cover shadow-lg" />}
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.16em]" style={{ color: website.color }}>Meet the founder</p>
              <h2 className="mt-3 text-3xl font-bold">{website.owner}</h2>
              <p className="mx-auto mt-4 max-w-2xl text-base leading-8 text-[#65636a]">{website.about}</p>
            </div>
          </div>
        </section>
      </main>
      <footer className="mx-auto flex max-w-6xl items-center justify-between px-6 py-8 text-sm text-[#77747b] md:px-10">
        <span>© {new Date().getFullYear()} {website.businessName}</span>
        <a href="#" className="font-bold" style={{ color: website.color }}>Back to top</a>
      </footer>
      <a href={window.location.pathname} className="fixed bottom-5 left-5 rounded-full bg-[#242329] px-4 py-2.5 text-xs font-bold text-white shadow-lg">← Back to Buildly</a>
    </div>
  )
}

const GeneratedAppPreview = ({ prompt }: { prompt: string }) => {
  const title = appName(prompt)
  const [entries, setEntries] = useState([
    { id: 1, text: 'Explore your new app', done: true },
    { id: 2, text: 'Add your first item', done: false },
  ])
  const [newEntry, setNewEntry] = useState('')
  const addEntry = (event: FormEvent) => {
    event.preventDefault()
    if (!newEntry.trim()) return
    setEntries((current) => [...current, { id: Date.now(), text: newEntry.trim(), done: false }])
    setNewEntry('')
  }
  const completed = entries.filter((entry) => entry.done).length

  return (
    <div className="min-h-screen bg-[#f4f2f8] text-[#242329]">
      <header className="border-b border-[#e3dfeb] bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#7257d5] text-white"><Icon name="app" /></span>
            <div><p className="font-display font-bold">{title}</p><p className="text-xs text-[#85818b]">Built with Buildly</p></div>
          </div>
          <a href={window.location.pathname} className="rounded-full border border-[#ddd8e5] px-4 py-2 text-xs font-bold transition hover:bg-[#f6f3fa]">Back to Buildly</a>
        </div>
      </header>
      <main className="mx-auto max-w-3xl px-5 py-12">
        <div className="rounded-[28px] bg-gradient-to-br from-[#775bd4] to-[#5036a7] p-7 text-white shadow-[0_20px_50px_rgba(81,54,169,.22)] sm:p-9">
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-white/65">Your workspace</p>
          <h1 className="font-display mt-2 text-3xl font-bold tracking-[-0.04em]">{title}</h1>
          <p className="mt-3 max-w-xl text-sm leading-6 text-white/75">{prompt}</p>
          <div className="mt-7 flex items-center gap-3">
            <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/20"><div className="h-full rounded-full bg-white transition-all" style={{ width: `${entries.length ? completed / entries.length * 100 : 0}%` }} /></div>
            <span className="text-xs font-bold">{completed}/{entries.length} complete</span>
          </div>
        </div>

        <section className="mt-6 rounded-[24px] border border-[#e3dfea] bg-white p-5 shadow-[0_10px_35px_rgba(45,38,64,.06)] sm:p-7">
          <h2 className="font-display text-lg font-bold">Your items</h2>
          <form onSubmit={addEntry} className="mt-4 flex gap-2">
            <input value={newEntry} onChange={(event) => setNewEntry(event.target.value)} placeholder="Add something new..." className="min-w-0 flex-1 rounded-xl border border-[#ddd8e5] px-4 py-3 text-sm outline-none focus:border-[#8069cf] focus:ring-2 focus:ring-[#e8e1fa]" />
            <button type="submit" disabled={!newEntry.trim()} className="rounded-xl bg-[#7257d5] px-5 text-sm font-bold text-white transition hover:bg-[#6247be] disabled:opacity-40">Add</button>
          </form>
          <div className="mt-5 space-y-2">
            {entries.map((entry) => (
              <div key={entry.id} className="flex items-center gap-3 rounded-xl border border-[#ece9ef] p-3.5">
                <button type="button" onClick={() => setEntries((current) => current.map((item) => item.id === entry.id ? { ...item, done: !item.done } : item))} className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border text-xs transition ${entry.done ? 'border-[#7257d5] bg-[#7257d5] text-white' : 'border-[#c8c3cf] hover:border-[#7257d5]'}`} aria-label={entry.done ? 'Mark incomplete' : 'Mark complete'}>{entry.done && '✓'}</button>
                <span className={`flex-1 text-sm font-medium ${entry.done ? 'text-[#9a969f] line-through' : ''}`}>{entry.text}</span>
                <button type="button" onClick={() => setEntries((current) => current.filter((item) => item.id !== entry.id))} className="px-2 text-lg text-[#aaa5ae] transition hover:text-[#d05b62]" aria-label={`Delete ${entry.text}`}>×</button>
              </div>
            ))}
            {!entries.length && <p className="py-8 text-center text-sm text-[#96919b]">Nothing here yet. Add your first item above.</p>}
          </div>
        </section>
      </main>
    </div>
  )
}

const GeneratedGamePreview = ({ prompt }: { prompt: string }) => {
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(20)
  const [playing, setPlaying] = useState(false)
  const [target, setTarget] = useState({ x: 50, y: 50 })

  useEffect(() => {
    if (!playing) return
    const timer = window.setInterval(() => setTimeLeft((time) => {
      if (time <= 1) {
        setPlaying(false)
        return 0
      }
      return time - 1
    }), 1000)
    return () => window.clearInterval(timer)
  }, [playing])

  const startGame = () => {
    setScore(0)
    setTimeLeft(20)
    setTarget({ x: 20 + Math.random() * 60, y: 20 + Math.random() * 60 })
    setPlaying(true)
  }
  const hitTarget = () => {
    setScore((value) => value + 1)
    setTarget({ x: 8 + Math.random() * 84, y: 10 + Math.random() * 80 })
  }

  return (
    <div className="min-h-screen bg-[#171522] px-5 py-8 text-white">
      <main className="mx-auto max-w-4xl">
        <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
          <div><p className="text-xs font-bold uppercase tracking-[0.15em] text-[#918aa8]">Built with Buildly</p><h1 className="font-display mt-1 text-3xl font-bold">{gameName(prompt)}</h1></div>
          <div className="flex gap-2">
            <span className="rounded-xl bg-[#29263a] px-4 py-2.5 text-sm font-bold">Score: {score}</span>
            <span className="rounded-xl bg-[#29263a] px-4 py-2.5 text-sm font-bold">Time: {timeLeft}s</span>
          </div>
        </div>
        <div className="relative h-[55vh] min-h-[390px] overflow-hidden rounded-[30px] border border-[#49445e] bg-[radial-gradient(circle_at_50%_30%,#342d58,#1e1b2b)] shadow-2xl">
          {!playing && <div className="absolute inset-0 z-10 grid place-items-center bg-[#181622]/55 backdrop-blur-sm"><div className="text-center"><p className="max-w-md px-6 text-sm leading-6 text-[#aaa4b9]">{prompt}</p><button type="button" onClick={startGame} className="mt-5 rounded-[14px] bg-[#7659d4] px-7 py-3.5 text-sm font-bold transition hover:scale-105 hover:bg-[#8569df]">{timeLeft === 0 ? `Play again — score ${score}` : 'Start game'}</button></div></div>}
          {playing && <button type="button" onClick={hitTarget} aria-label="Score target" className="absolute grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-gradient-to-br from-[#ffd66b] to-[#ff7b54] text-2xl text-white shadow-[0_0_30px_rgba(255,154,80,.65)] transition-[left,top,transform] hover:scale-110" style={{ left: `${target.x}%`, top: `${target.y}%` }}>★</button>}
        </div>
        <div className="mt-5 flex items-center justify-between">
          <a href={window.location.pathname} className="rounded-full border border-[#423e51] px-4 py-2 text-xs font-bold text-[#b6b0c4] transition hover:bg-[#29263a]">← Back to Buildly</a>
          <p className="text-xs text-[#777187]">Hit as many stars as you can in 20 seconds.</p>
        </div>
      </main>
    </div>
  )
}

export default function App() {
  const [prompt, setPrompt] = useState('')
  const [notice, setNotice] = useState('')
  const [mode, setMode] = useState<Mode>('app')
  const [result, setResult] = useState<GeneratedResult | null>(null)
  const [generating, setGenerating] = useState(false)
  const [website, setWebsite] = useState<WebsiteDetails>({ color: '#7257d5', businessName: '', owner: '', about: '', blurb: '', font: 'Modern & clean', logo: '', founderPhoto: '' })
  const [showAll, setShowAll] = useState(false)
  const [panel, setPanel] = useState<'help' | 'profile' | 'project' | null>(null)
  const [selectedProject, setSelectedProject] = useState<(typeof projects)[number] | null>(null)
  const ideaRef = useRef<HTMLTextAreaElement>(null)

  const startNewProject = () => {
    setPrompt('')
    setNotice('')
    setResult(null)
    window.scrollTo({ top: 0, behavior: 'smooth' })
    window.setTimeout(() => ideaRef.current?.focus(), 400)
  }

  const openProject = (project: (typeof projects)[number]) => {
    setSelectedProject(project)
    setPanel('project')
  }

  const uploadImage = (file: File | undefined, field: 'logo' | 'founderPhoto') => {
    if (!file || !file.type.startsWith('image/')) return
    const reader = new FileReader()
    reader.onload = () => setWebsite((current) => ({ ...current, [field]: String(reader.result) }))
    reader.readAsDataURL(file)
  }

  const submit = (event: FormEvent) => {
    event.preventDefault()
    if (!prompt.trim()) return
    const text = prompt.toLowerCase()
    const inferredMode: Mode = text.includes('website') ? 'site' : text.includes('game') ? 'game' : text.includes('fix') || text.includes('problem') || text.includes('error') ? 'bug' : text.includes('improve') || text.includes('feature') ? 'bulb' : mode
    if (inferredMode === 'site' && (!website.businessName.trim() || !website.owner.trim() || !website.about.trim() || !website.blurb.trim())) {
      setMode('site')
      setNotice('Please complete the website details so we can create the right result.')
      return
    }
    setMode(inferredMode)
    setNotice('')
    setResult(null)
    setGenerating(true)
    window.setTimeout(() => {
      setResult(resultFor(inferredMode, prompt.trim(), website))
      if (inferredMode === 'site') {
        try {
          localStorage.setItem('buildly-published-website', JSON.stringify(website))
        } catch {
          // The preview still works in the current tab if browser storage is unavailable.
        }
      }
      if (inferredMode === 'app') localStorage.setItem('buildly-generated-app', prompt.trim())
      if (inferredMode === 'game') localStorage.setItem('buildly-generated-game', prompt.trim())
      setGenerating(false)
      window.setTimeout(() => document.querySelector('#generated-result')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 50)
    }, 650)
  }

  if (window.location.hash.startsWith('#/site/')) {
    let savedWebsite = website
    try {
      const stored = localStorage.getItem('buildly-published-website')
      if (stored) savedWebsite = JSON.parse(stored) as WebsiteDetails
    } catch {
      // Fall back to the current website details.
    }
    return <WebsitePreview website={savedWebsite} />
  }

  if (window.location.hash.startsWith('#/app/')) {
    return <GeneratedAppPreview prompt={localStorage.getItem('buildly-generated-app') || prompt || 'A simple app to organize your ideas'} />
  }

  if (window.location.hash.startsWith('#/game/')) {
    return <GeneratedGamePreview prompt={localStorage.getItem('buildly-generated-game') || prompt || 'A quick reaction game'} />
  }

  return (
    <div className="min-h-screen overflow-hidden bg-[#faf9f7] text-[#242329]">
      <header className="fixed inset-x-0 top-0 z-20 flex h-[72px] items-center justify-between border-b border-[#eae7e1] bg-[#faf9f7]/85 px-5 backdrop-blur-xl md:px-8">
        <a href="#" className="flex items-center gap-2.5" aria-label="Buildly home">
          <span className="grid h-9 w-9 rotate-[-3deg] place-items-center rounded-[12px] bg-gradient-to-br from-[#8064df] to-[#5e42bd] text-white shadow-[0_6px_16px_rgba(91,66,182,.25)]"><Icon name="sparkles" className="h-5 w-5" /></span>
          <span className="font-display text-[20px] font-bold tracking-[-0.04em]">Buildly</span>
        </a>
        <div className="flex items-center gap-3">
          <button type="button" onClick={() => setPanel('help')} className="hidden rounded-full px-4 py-2 text-sm font-semibold text-[#676767] transition hover:bg-white sm:block">Help</button>
          <button type="button" onClick={() => setPanel('profile')} className="grid h-9 w-9 place-items-center rounded-full bg-[#dcd3f6] text-sm font-bold text-[#644ab9] transition hover:scale-105" aria-label="Open profile">AJ</button>
        </div>
      </header>

      <aside className="fixed inset-y-[72px] left-0 hidden w-[232px] flex-col border-r border-[#eae7e1] bg-[#faf9f7] px-4 py-6 lg:flex">
        <nav className="space-y-1">
          <a href="#" className="flex items-center gap-3 rounded-xl bg-white px-3.5 py-3 text-sm font-semibold shadow-[0_1px_2px_rgba(0,0,0,.04)]"><Icon name="home" />Home</a>
          <a href="#projects" className="flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-medium text-[#686868] transition hover:bg-white"><Icon name="folder" />My projects</a>
        </nav>
        <div className="mt-auto rounded-[20px] border border-[#e1d9f6] bg-gradient-to-br from-[#f1edfc] to-[#e8e0fa] p-4 shadow-[0_8px_24px_rgba(83,61,140,.08)]">
          <div className="mb-2 flex h-8 w-8 items-center justify-center rounded-lg bg-white text-[#7257d5]"><Icon name="sparkles" className="h-4 w-4" /></div>
          <p className="text-sm font-bold">Have an idea?</p>
          <p className="mt-1 text-xs leading-5 text-[#6e687c]">Just describe it in your own words. We’ll handle the rest.</p>
        </div>
      </aside>

      <main className="relative px-5 pb-20 pt-[112px] md:px-10 lg:ml-[232px] lg:px-14">
        <div className="pointer-events-none absolute left-[8%] top-32 h-52 w-52 rounded-full bg-[#e8ddff] opacity-50 blur-[80px]" />
        <div className="pointer-events-none absolute right-[4%] top-24 h-64 w-64 rounded-full bg-[#d9f0e8] opacity-50 blur-[90px]" />
        <div className="relative mx-auto max-w-[1050px]">
          <section className="mx-auto max-w-[760px] text-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-[#ded5f5] bg-white/70 px-3.5 py-1.5 text-xs font-bold text-[#6349bb] shadow-sm backdrop-blur"><Icon name="sparkles" className="h-4 w-4" />Your idea, built faster</span>
            <h1 className="font-display mt-5 text-[40px] font-bold leading-[1.06] tracking-[-0.055em] sm:text-[56px]">What will you <span className="bg-gradient-to-r from-[#7658d4] to-[#aa63a7] bg-clip-text text-transparent">create today?</span></h1>
            <p className="mx-auto mt-5 max-w-[580px] text-base leading-7 text-[#706e75] sm:text-[17px]">Describe your idea in your own words. Buildly turns it into something real—no coding experience needed.</p>

            <form onSubmit={submit} className="mt-9 rounded-[26px] border border-white bg-white/90 p-2.5 text-left shadow-[0_18px_60px_rgba(59,47,90,.12),0_0_0_1px_rgba(65,54,84,.08)] backdrop-blur transition focus-within:shadow-[0_20px_65px_rgba(75,55,140,.17),0_0_0_2px_rgba(126,99,214,.28)]">
              <label htmlFor="idea" className="sr-only">Describe your idea</label>
              <textarea
                ref={ideaRef}
                id="idea"
                value={prompt}
                onChange={(event) => { setPrompt(event.target.value); setNotice(''); if (event.target.value.toLowerCase().includes('website')) setMode('site') }}
                placeholder="Example: Make a website for my school science fair..."
                className="min-h-[92px] w-full resize-none rounded-xl bg-transparent px-3.5 py-3 text-[15px] leading-6 outline-none placeholder:text-[#a5a5a1]"
              />
              {mode === 'site' && (
                <div className="mx-1 mb-3 rounded-[18px] border border-[#e7e1f0] bg-[#faf8fd] p-4 sm:p-5">
                  <div className="mb-4 flex items-center gap-3">
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#d8f0eb] text-[#308b79]"><Icon name="site" className="h-5 w-5" /></span>
                    <div>
                      <p className="font-display text-sm font-bold">Tell us about your website</p>
                      <p className="mt-0.5 text-xs text-[#7e7a83]">These details shape the generated result.</p>
                    </div>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded-xl border border-[#ddd8e3] bg-white p-3">
                      <p className="text-xs font-bold text-[#615e66]">Business logo</p>
                      <div className="mt-2 flex items-center gap-3">
                        <span className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-xl border border-dashed border-[#cfc7dc] bg-[#f7f4fb] text-[#8068c6]">
                          {website.logo ? <img src={website.logo} alt="Business logo preview" className="h-full w-full object-contain" /> : <Icon name="site" className="h-5 w-5" />}
                        </span>
                        <label className="cursor-pointer rounded-lg bg-[#eee9f8] px-3 py-2 text-xs font-bold text-[#654cbb] transition hover:bg-[#e4dcf5]">
                          {website.logo ? 'Change logo' : 'Upload logo'}
                          <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="sr-only" onChange={(event) => uploadImage(event.target.files?.[0], 'logo')} />
                        </label>
                      </div>
                    </div>
                    <div className="rounded-xl border border-[#ddd8e3] bg-white p-3">
                      <p className="text-xs font-bold text-[#615e66]">Founder photo</p>
                      <div className="mt-2 flex items-center gap-3">
                        <span className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-full border border-dashed border-[#cfc7dc] bg-[#f7f4fb] text-xs font-bold text-[#8068c6]">
                          {website.founderPhoto ? <img src={website.founderPhoto} alt="Founder preview" className="h-full w-full object-cover" /> : 'Photo'}
                        </span>
                        <label className="cursor-pointer rounded-lg bg-[#eee9f8] px-3 py-2 text-xs font-bold text-[#654cbb] transition hover:bg-[#e4dcf5]">
                          {website.founderPhoto ? 'Change photo' : 'Upload photo'}
                          <input type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" onChange={(event) => uploadImage(event.target.files?.[0], 'founderPhoto')} />
                        </label>
                      </div>
                    </div>
                    <label className="text-xs font-bold text-[#615e66]">
                      Business name
                      <input required value={website.businessName} onChange={(event) => setWebsite({ ...website, businessName: event.target.value })} placeholder="Evergreen Studio" className="mt-1.5 w-full rounded-xl border border-[#ddd8e3] bg-white px-3.5 py-3 text-sm font-medium outline-none transition focus:border-[#8f78d7] focus:ring-2 focus:ring-[#e7e0f8]" />
                    </label>
                    <label className="text-xs font-bold text-[#615e66]">
                      Founder or owner
                      <input required value={website.owner} onChange={(event) => setWebsite({ ...website, owner: event.target.value })} placeholder="Jordan Lee" className="mt-1.5 w-full rounded-xl border border-[#ddd8e3] bg-white px-3.5 py-3 text-sm font-medium outline-none transition focus:border-[#8f78d7] focus:ring-2 focus:ring-[#e7e0f8]" />
                    </label>
                    <label className="text-xs font-bold text-[#615e66]">
                      Brand color
                      <span className="mt-1.5 flex h-[46px] items-center gap-2 rounded-xl border border-[#ddd8e3] bg-white px-2">
                        <input type="color" value={website.color} onChange={(event) => setWebsite({ ...website, color: event.target.value })} className="h-8 w-9 cursor-pointer rounded-lg border-0 bg-transparent p-0" aria-label="Choose brand color" />
                        <input value={website.color} onChange={(event) => setWebsite({ ...website, color: event.target.value })} className="min-w-0 flex-1 bg-transparent px-1 text-sm font-medium uppercase outline-none" aria-label="Brand color value" />
                      </span>
                    </label>
                    <label className="text-xs font-bold text-[#615e66]">
                      Font choice
                      <select value={website.font} onChange={(event) => setWebsite({ ...website, font: event.target.value })} className="mt-1.5 h-[46px] w-full rounded-xl border border-[#ddd8e3] bg-white px-3.5 text-sm font-medium outline-none transition focus:border-[#8f78d7] focus:ring-2 focus:ring-[#e7e0f8]">
                        <option>Modern & clean</option>
                        <option>Bold & playful</option>
                        <option>Elegant & classic</option>
                        <option>Friendly & rounded</option>
                        <option>Minimal & editorial</option>
                      </select>
                    </label>
                    <label className="text-xs font-bold text-[#615e66] sm:col-span-2">
                      About me
                      <textarea required value={website.about} onChange={(event) => setWebsite({ ...website, about: event.target.value })} placeholder="Share a little about the person behind the business..." className="mt-1.5 min-h-[74px] w-full resize-none rounded-xl border border-[#ddd8e3] bg-white px-3.5 py-3 text-sm font-medium leading-5 outline-none transition focus:border-[#8f78d7] focus:ring-2 focus:ring-[#e7e0f8]" />
                    </label>
                    <label className="text-xs font-bold text-[#615e66] sm:col-span-2">
                      Business description
                      <textarea required value={website.blurb} onChange={(event) => setWebsite({ ...website, blurb: event.target.value })} placeholder="What does the business offer, and who is it for?" className="mt-1.5 min-h-[74px] w-full resize-none rounded-xl border border-[#ddd8e3] bg-white px-3.5 py-3 text-sm font-medium leading-5 outline-none transition focus:border-[#8f78d7] focus:ring-2 focus:ring-[#e7e0f8]" />
                    </label>
                  </div>
                </div>
              )}
              <div className="flex items-center justify-between gap-3 border-t border-[#efeeeb] px-2 pt-2.5">
                <span className="hidden text-xs text-[#999893] sm:block">Tip: Include who it’s for and what it should do.</span>
                <button type="submit" disabled={!prompt.trim() || generating} className="ml-auto flex items-center gap-2 rounded-[13px] bg-gradient-to-r from-[#7659d4] to-[#6848c5] px-5 py-3 text-sm font-bold text-white shadow-[0_5px_16px_rgba(103,72,195,.28)] transition hover:-translate-y-0.5 hover:shadow-[0_8px_22px_rgba(103,72,195,.34)] disabled:cursor-not-allowed disabled:opacity-40">
                  {generating ? 'Generating…' : 'Generate result'} <Icon name="arrow" className="h-4 w-4" />
                </button>
              </div>
            </form>
            {notice && <p role="status" className="mt-3 rounded-xl bg-[#e5f4ee] px-4 py-3 text-sm font-medium text-[#287363]">{notice}</p>}
          </section>

          {(generating || result) && (
            <section id="generated-result" className="mx-auto mt-10 max-w-[820px]" aria-live="polite">
              {generating ? (
                <div className="rounded-[24px] border border-[#e2dcef] bg-white/85 p-7 shadow-[0_16px_50px_rgba(55,42,88,.09)]">
                  <div className="flex items-center gap-3">
                    <span className="h-3 w-3 animate-pulse rounded-full bg-[#7257d5]" />
                    <p className="font-display font-semibold">Turning your idea into a result…</p>
                  </div>
                  <div className="mt-5 space-y-3">
                    <div className="h-3 w-4/5 animate-pulse rounded-full bg-[#eeeaf4]" />
                    <div className="h-3 w-3/5 animate-pulse rounded-full bg-[#eeeaf4]" />
                  </div>
                </div>
              ) : result && (
                <div className="overflow-hidden rounded-[26px] border border-[#ddd6eb] bg-white shadow-[0_20px_60px_rgba(55,42,88,.12)]">
                  <div className="grid md:grid-cols-[1.25fr_.75fr]">
                    <div className="p-6 sm:p-8">
                      <span className="inline-flex items-center gap-2 rounded-full bg-[#ece6fb] px-3 py-1.5 text-xs font-bold text-[#674dbd]"><Icon name="sparkles" className="h-3.5 w-3.5" />{result.label}</span>
                      <h2 className="font-display mt-4 text-2xl font-bold tracking-[-0.04em] sm:text-3xl">{result.title}</h2>
                      <p className="mt-3 text-sm leading-6 text-[#6f6c74]">{result.summary}</p>
                      <div className="mt-6 space-y-3">
                        {result.items.map((item) => (
                          <div key={item} className="flex items-center gap-3 text-sm font-semibold">
                            <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#e3f3ed] text-xs text-[#2d806c]">✓</span>{item}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="flex flex-col justify-between bg-gradient-to-br from-[#eee9fb] to-[#e2f0ec] p-6 sm:p-8">
                      <div>
                        <div className="flex items-center gap-3">
                          <span className="grid h-12 w-12 place-items-center overflow-hidden rounded-2xl bg-white text-[#7054ca] shadow-sm">
                            {result.mode === 'site' && website.logo ? <img src={website.logo} alt="" className="h-full w-full object-contain p-1" /> : <Icon name={result.mode} className="h-6 w-6" />}
                          </span>
                          {result.mode === 'site' && website.founderPhoto && <img src={website.founderPhoto} alt={website.owner} className="h-12 w-12 rounded-full border-2 border-white object-cover shadow-sm" />}
                        </div>
                        <p className="mt-5 text-xs font-bold uppercase tracking-[0.12em] text-[#76717c]">Ready for the next step</p>
                        <p className="font-display mt-2 text-lg font-bold">Your result can now become a working project.</p>
                      </div>
                      {result.mode === 'site' ? (
                        <div className="mt-8">
                          <a href={websiteLink(website.businessName)} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-[14px] bg-[#28252f] px-4 py-3.5 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-[#7257d5]">Open website <Icon name="arrow" className="h-4 w-4" /></a>
                          <div className="mt-2 grid grid-cols-2 gap-2">
                            <button type="button" onClick={() => { navigator.clipboard.writeText(websiteLink(website.businessName)); setNotice('Website link copied to your clipboard.') }} className="rounded-lg px-2 py-2 text-xs font-semibold text-[#665f70] transition hover:bg-white/50" title={websiteLink(website.businessName)}>Copy link</button>
                            <button type="button" onClick={() => downloadCode(`${website.businessName.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'website'}-index.html`, websiteCode(website))} className="rounded-lg bg-white/60 px-2 py-2 text-xs font-bold text-[#5f4aa8] transition hover:bg-white">Download code</button>
                          </div>
                        </div>
                      ) : result.mode === 'app' ? (
                        <div className="mt-8">
                          <a href={appLink(prompt)} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-[14px] bg-[#28252f] px-4 py-3.5 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-[#7257d5]">Launch your app <Icon name="arrow" className="h-4 w-4" /></a>
                          <div className="mt-2 grid grid-cols-2 gap-2">
                            <button type="button" onClick={() => { navigator.clipboard.writeText(appLink(prompt)); setNotice('App link copied to your clipboard.') }} className="rounded-lg px-2 py-2 text-xs font-semibold text-[#665f70] transition hover:bg-white/50">Copy link</button>
                            <button type="button" onClick={() => downloadCode(`${appName(prompt).toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'app'}-index.html`, appCode(prompt))} className="rounded-lg bg-white/60 px-2 py-2 text-xs font-bold text-[#5f4aa8] transition hover:bg-white">Download code</button>
                          </div>
                        </div>
                      ) : result.mode === 'game' ? (
                        <div className="mt-8">
                          <a href={gameLink(prompt)} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-[14px] bg-[#28252f] px-4 py-3.5 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-[#7257d5]">Play your game <Icon name="arrow" className="h-4 w-4" /></a>
                          <div className="mt-2 grid grid-cols-2 gap-2">
                            <button type="button" onClick={() => { navigator.clipboard.writeText(gameLink(prompt)); setNotice('Game link copied to your clipboard.') }} className="rounded-lg px-2 py-2 text-xs font-semibold text-[#665f70] transition hover:bg-white/50">Copy link</button>
                            <button type="button" onClick={() => downloadCode(`${gameName(prompt).toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'game'}-index.html`, gameCode(prompt))} className="rounded-lg bg-white/60 px-2 py-2 text-xs font-bold text-[#5f4aa8] transition hover:bg-white">Download code</button>
                          </div>
                        </div>
                      ) : (
                        <button type="button" onClick={() => setNotice(`${result.action} started successfully.`)} className="mt-8 flex items-center justify-center gap-2 rounded-[14px] bg-[#28252f] px-4 py-3.5 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-[#7257d5]">{result.action}<Icon name="arrow" className="h-4 w-4" /></button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </section>
          )}

          <section className="mt-14">
            <div className="mb-5 flex items-end justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.13em] text-[#8e8d89]">Quick start</p>
                <h2 className="font-display mt-1.5 text-xl font-bold tracking-[-0.035em]">Choose what you want to do</h2>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
              {starters.map((item) => (
                <button type="button" key={item.title} onClick={() => { setMode(item.mode); setResult(null); setPrompt(item.prompt); setNotice(''); window.scrollTo({ top: 0, behavior: 'smooth' }); window.setTimeout(() => ideaRef.current?.focus(), 400) }} className="quick-card group min-h-[176px] rounded-[20px] border border-[#e8e5df] bg-white/80 p-4 text-left shadow-[0_2px_8px_rgba(40,35,55,.03)] backdrop-blur transition hover:-translate-y-1.5 hover:border-[#d2c9ec] hover:shadow-[0_14px_34px_rgba(40,35,55,.09)]">
                  <span className={`grid h-10 w-10 place-items-center rounded-xl ${item.color}`}><Icon name={item.icon} /></span>
                  <h3 className="font-display mt-5 text-[15px] font-bold tracking-[-0.02em]">{item.title}</h3>
                  <p className="mt-1.5 text-[13px] leading-5 text-[#787875]">{item.copy}</p>
                  <Icon name="arrow" className="mt-3 h-4 w-4 text-[#a29dac] transition group-hover:translate-x-1 group-hover:text-[#7257d5]" />
                </button>
              ))}
            </div>
          </section>

          <section id="projects" className="mt-14">
            <div className="mb-5 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.13em] text-[#8e8d89]">Pick up where you left off</p>
                <h2 className="font-display mt-1.5 text-xl font-bold tracking-[-0.035em]">Recent projects</h2>
              </div>
              <button type="button" onClick={() => setShowAll((value) => !value)} className="text-sm font-bold text-[#7257d5] hover:text-[#5d43bc]">{showAll ? 'Show less' : 'View all'}</button>
            </div>
            <div className="overflow-hidden rounded-[20px] border border-[#e7e4de] bg-white/85 shadow-[0_8px_28px_rgba(44,39,54,.045)] backdrop-blur">
              {(showAll ? projects : projects.slice(0, 3)).map((project, index, visibleProjects) => (
                <button type="button" onClick={() => openProject(project)} key={project.title} className={`flex w-full items-center gap-4 p-4 text-left transition hover:bg-[#fbfafc] sm:px-5 ${index !== visibleProjects.length - 1 ? 'border-b border-[#ecebe8]' : ''}`}>
                  <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${project.color}`}><Icon name={project.icon} /></span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-bold">{project.title}</span>
                    <span className="mt-1 block text-xs text-[#8d8c88]">{project.type}</span>
                  </span>
                  <span className="hidden items-center gap-1.5 text-xs text-[#969590] sm:flex"><Icon name="clock" className="h-3.5 w-3.5" />{project.updated}</span>
                  <Icon name="arrow" className="h-4 w-4 text-[#aaa8a4]" />
                </button>
              ))}
            </div>
          </section>
        </div>
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-20 flex h-16 items-center justify-around border-t border-[#e4e3df] bg-white/95 px-6 backdrop-blur lg:hidden">
        <a href="#" className="flex flex-col items-center gap-1 text-[10px] font-bold text-[#7257d5]"><Icon name="home" className="h-5 w-5" />Home</a>
        <button type="button" onClick={startNewProject} className="-mt-7 grid h-12 w-12 place-items-center rounded-full border-4 border-[#f8f8f6] bg-[#7257d5] text-white shadow-lg" aria-label="New project"><Icon name="plus" /></button>
        <a href="#projects" className="flex flex-col items-center gap-1 text-[10px] font-medium text-[#777]"><Icon name="folder" className="h-5 w-5" />Projects</a>
      </nav>

      {panel && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-[#25202f]/35 p-5 backdrop-blur-sm" role="presentation" onMouseDown={() => setPanel(null)}>
          <section role="dialog" aria-modal="true" aria-label={panel === 'help' ? 'Help' : panel === 'profile' ? 'Profile' : 'Project details'} onMouseDown={(event) => event.stopPropagation()} className="w-full max-w-[430px] rounded-[26px] border border-white/70 bg-[#fdfcfb] p-6 shadow-[0_28px_80px_rgba(31,25,44,.25)]">
            <div className="flex items-start justify-between gap-4">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#ece6fc] text-[#7257d5]"><Icon name={panel === 'help' ? 'bulb' : panel === 'profile' ? 'sparkles' : selectedProject?.icon || 'folder'} /></span>
              <button type="button" onClick={() => setPanel(null)} className="grid h-9 w-9 place-items-center rounded-full bg-[#f0eeeb] text-xl text-[#68656d] transition hover:bg-[#e6e2dd]" aria-label="Close">×</button>
            </div>

            {panel === 'help' && (
              <>
                <h2 className="font-display mt-5 text-2xl font-bold tracking-[-0.04em]">How can we help?</h2>
                <p className="mt-2 text-sm leading-6 text-[#716f75]">Start with a simple sentence about what you want to make. Include who it’s for, what it should do, and any style you have in mind.</p>
                <button type="button" onClick={() => { setPanel(null); startNewProject() }} className="mt-6 w-full rounded-[14px] bg-[#7257d5] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#6348c0]">Try an idea</button>
              </>
            )}

            {panel === 'profile' && (
              <>
                <h2 className="font-display mt-5 text-2xl font-bold tracking-[-0.04em]">Alex Johnson</h2>
                <p className="mt-1 text-sm text-[#817e84]">alex@example.com</p>
                <div className="mt-6 grid grid-cols-2 gap-3">
                  <button type="button" onClick={() => { setPanel(null); document.querySelector('#projects')?.scrollIntoView() }} className="rounded-[14px] border border-[#e3dfda] bg-white px-4 py-3 text-sm font-bold transition hover:border-[#bfb1e8]">My projects</button>
                  <button type="button" onClick={() => { setPanel(null); setNotice('Settings are ready for your preferences.') }} className="rounded-[14px] border border-[#e3dfda] bg-white px-4 py-3 text-sm font-bold transition hover:border-[#bfb1e8]">Settings</button>
                </div>
              </>
            )}

            {panel === 'project' && selectedProject && (
              <>
                <p className="mt-5 text-xs font-bold uppercase tracking-[0.13em] text-[#8e8d89]">{selectedProject.type}</p>
                <h2 className="font-display mt-1 text-2xl font-bold tracking-[-0.04em]">{selectedProject.title}</h2>
                <p className="mt-2 text-sm leading-6 text-[#716f75]">Last edited {selectedProject.updated}. Open it to continue building, previewing, and improving your project.</p>
                <button type="button" onClick={() => { setPanel(null); setNotice(`${selectedProject.title} is open and ready to edit.`); window.scrollTo({ top: 0, behavior: 'smooth' }) }} className="mt-6 flex w-full items-center justify-center gap-2 rounded-[14px] bg-[#7257d5] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#6348c0]">Open project <Icon name="arrow" className="h-4 w-4" /></button>
              </>
            )}
          </section>
        </div>
      )}
    </div>
  )
}
